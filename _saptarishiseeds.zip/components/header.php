<header class="header">
    <div class="container">
        <div class="header-inner">
            <div class="logo">
                <a href="./index.php">
                    <img src="./assets/images/saptarishiseed-logo.png" alt="Saptarishi Seeds Logo">
                </a>
            </div>

            <button class="menu-btn">
                <i class="fa-solid fa-bars-staggered"></i>
            </button>

            <div class="header-menu">
                <nav class="navbar">
                    <ul class="nav-list">
                        <li class="nav-item"><a href="./index.php" class="nav-link">Home</a></li>
                        <li class="nav-item"><a href="./products.php" class="nav-link">Products</a></li>
                        <li class="nav-item"><a href="./about-us.php" class="nav-link">About Us</a></li>
                        <li class="nav-item"><a href="./contact-us.php" class="nav-link">Contact Us</a></li>
                    </ul>
                </nav>

                <div class="header-cta">
                    
                    <button id="openCatalog" class="btn btn-primary">Get Catalog</button>
                </div>
            </div>
        </div>
    </div>
</header>
<div class="catalog-popup" id="catalogPopup">
    <div class="catalog-popup-wrapper">
        <span class="popup-close" id="closeCatalog"><i class="fa-solid fa-xmark"></i></span>
        <div class="catalog-popup-header">
            <h2 class="catalog-popup-title">Download Catalog</h2>
            <p class="catalog-popup-into">Get latest seeds details</p>
        </div>
       <form id="catalogForm" method="post">
    
    <div class="form-box">
        <label for="name">Name</label>
        <input type="text" id="name" name="name" placeholder="Enter your name" required>
    </div>

    <div class="form-box">
        <label for="phone">Phone *</label>
        <input type="tel" id="phone" name="phone" placeholder="Enter your phone number" required>
    </div>

    <div class="form-box">
        <label for="email">Email (optional)</label>
        <input type="email" id="email" name="email" placeholder="Enter your email">
    </div>

    <div class="form-box">
        <label for="city">City</label>
        <input type="text" id="city" name="city" placeholder="Enter your city">
    </div>

    <div class="form-check">
        <input type="checkbox" id="whatsapp" checked>
        <label for="whatsapp">I agree to be contacted on WhatsApp</label>
    </div>

    <button type="submit"  >Get Free Catalog</button>

    <p class="form-note">We respect your privacy</p>

</form>
    </div>
    
</div>